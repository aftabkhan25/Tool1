<html>
<frameset rows="192,*" bordercolor="white" border="0" framespacing="0" frameborder="NO">
<frame src="http://perdu.com"/>
<frame src="<?php echo $_GET["url"]; ?>" />
</frameset>

