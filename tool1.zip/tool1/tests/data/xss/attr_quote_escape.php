<html>
<body>
<?php $class = isset($_GET["class"]) ? $_GET["class"] : "standard"; ?>
<pre class='<?=$class?>'>Hello there</pre>
</body>
</html>