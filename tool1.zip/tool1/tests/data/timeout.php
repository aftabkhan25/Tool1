<?php
sleep(5);
?>